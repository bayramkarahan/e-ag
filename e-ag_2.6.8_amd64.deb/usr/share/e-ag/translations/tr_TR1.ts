<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="tr_TR">
<context>
    <name>CustomInputDialog</name>
    <message>
        <location filename="../CustomInputDialog.h" line="21"/>
        <source>Tamam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../CustomInputDialog.h" line="22"/>
        <source>İptal</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../baseWidget.h" line="24"/>
        <location filename="../selectpc.h" line="35"/>
        <source>VNC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseWidget.h" line="37"/>
        <source>noVNC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseWidget.h" line="52"/>
        <source>RDP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseWidget.h" line="66"/>
        <location filename="../selectpc.h" line="46"/>
        <source>Terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseWidget.h" line="80"/>
        <source>Pc Seç</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseWidget.h" line="100"/>
        <location filename="../baseWidget.h" line="103"/>
        <location filename="../loginLogoutWidget.h" line="117"/>
        <location filename="../loginLogoutWidget.h" line="120"/>
        <location filename="../vncrdpWidget.h" line="305"/>
        <source>İstemci Parolası</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseWidget.h" line="101"/>
        <location filename="../loginLogoutWidget.h" line="118"/>
        <source> İstemcideki Kullanıcının Adını Giriniz :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseWidget.h" line="104"/>
        <location filename="../loginLogoutWidget.h" line="121"/>
        <source> Kullanıcının Parolasını Giriniz :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseWidget.h" line="116"/>
        <source>Uyarı</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseWidget.h" line="116"/>
        <source>ftp için nemo, thunar, nautilus, dolphi, pcmanfm vb. uygulama bulunamadı.
Bu uygulamalardan birini kururarak ftp işlemi yapabilirsiniz..</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseWidget.h" line="140"/>
        <source>Pc Aç</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="13"/>
        <source>Ayarlar Penceresi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="36"/>
        <source>İstemci Liste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="52"/>
        <source>Web Engelleme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="68"/>
        <source>Gizli Bilgisayarlar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="82"/>
        <source>Hakkında</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="97"/>
        <location filename="../baseWidget.h" line="151"/>
        <location filename="../filecopyWidget.h" line="314"/>
        <location filename="../messageWidget.h" line="62"/>
        <location filename="../runcommandWidget.h" line="84"/>
        <location filename="../videoWidget.h" line="227"/>
        <location filename="../vncrdpWidget.h" line="120"/>
        <source>Yardım</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="105"/>
        <source>&lt;center&gt;&lt;h2&gt;Ayarlar&lt;/h2&gt;&lt;/center&gt;&lt;center&gt;&lt;img src=&quot;:/icons/ayar.png&quot;&gt;&lt;/center&gt; &lt;br/&gt;&lt;center&gt;&lt;img src=&quot;:/icons/userayar.png&quot;/&gt;&lt;/center&gt;&lt;br/&gt;1-Uygulamadaki Yerel Ağ: bulunduğumuz ağ örn:192.168.1.255 şeklinde girilmeli.&lt;br/&gt;&lt;br/&gt;2-Uygulamadaki Tcp Port: yazılımın kullandığı port boş bırakılırsa 7879 olarak ayarlar.&lt;br/&gt;&lt;br/&gt;3-İstemcilerin listesini İstemci Listele seçeneği ile yapabilir ve listeyi yazdırabiliriz.&lt;br/&gt;&lt;br/&gt;4-Gizlenmiş istemcileri tekrar listede görünmesi için Gizli Bilgisayarlar Göster seçeneğini kullanabilirsiniz.&lt;br/&gt;&lt;br/&gt;5-İstemcilerde web sitesini kelime bazlı kısıtlamaları için; Web Engeleme seçeneğini kullanabilirsiniz.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="132"/>
        <source>Ayarlar Yardım Penceresi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="185"/>
        <location filename="../SettingsWidget.h" line="303"/>
        <location filename="../wolWidget.h" line="22"/>
        <source>Ip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="186"/>
        <location filename="../SettingsWidget.h" line="302"/>
        <location filename="../wolWidget.h" line="23"/>
        <source>Mac</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="187"/>
        <location filename="../SettingsWidget.h" line="304"/>
        <location filename="../wolWidget.h" line="24"/>
        <source>Adı</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="188"/>
        <location filename="../SettingsWidget.h" line="305"/>
        <source>Host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="230"/>
        <source>Seçili Bilgisayarı Göster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="287"/>
        <source>İstemci Listesi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="306"/>
        <source>Listele</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="345"/>
        <source>Yazdır</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="356"/>
        <location filename="../SettingsWidget.h" line="363"/>
        <source>Ağ IP ve Mac Adres Listesi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="416"/>
        <source>Web Filtresi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="432"/>
        <source>Index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="433"/>
        <source>Engelenen Kelime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="461"/>
        <source>Kelimeyi Kaydet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="492"/>
        <source>Profili Sil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="532"/>
        <source>Yeni Profil Ekle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="554"/>
        <source>Açık Pc&apos;lerin Web Filtre Listesini Güncelle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="606"/>
        <source>Ağ Profil Listesi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="679"/>
        <source>Kaydet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseWidget.h" line="160"/>
        <source>&lt;center&gt;&lt;h2&gt;Temel İşlemler&lt;/h2&gt;&lt;/center&gt;&lt;center&gt;&lt;img src=&quot;:/icons/temelislem.png&quot; /&gt;&lt;/center&gt; &lt;br/&gt;&lt;br/&gt;1-Vnc seçeneği istemcide açık olan masaüstüne erişilir.&lt;br/&gt;&lt;br/&gt;2-noVnc seçeneği istemcide açık olan masaüstüne web tarayısıyla erişilir.&lt;br/&gt;&lt;br/&gt;3-Rdp ile istemci üzerinde açık olmayan bir kullanıcı ile masaüstüne erişilir.&lt;br/&gt;&lt;br/&gt;4-Terminal ile  ssh üzerinden konsoluna bağlanmak kullanılır.&lt;br/&gt;&lt;br/&gt;5-FTP ile dosya yöneticisini kullanarak istemciye bağlanıp dosya transferi için kullanılır.&lt;br/&gt;&lt;br/&gt;6-İstemcinin uzaktan başlatmak için Pc Aç seçeneği kullanılabilir.Pc Aç seçeneği için; İstemcinin BIOS seçeneklerinden Wake On Lan seçeneği aktif edilmeli. &lt;br/&gt;&lt;br/&gt;7-İstemci simgelerinin altındaki P V S R X işaretleri servisleri ifade eder.&lt;center&gt;&lt;img src=&quot;:/icons/istemci.png&quot; /&gt;&lt;/center&gt;Simgeler yeşilse servis çalışıyor. Kırmızı ise servis çalışmıyordur.&lt;br/&gt;P=İstemci, yeşil=istemci açık/kırmızı=istemci kapalı&lt;br/&gt;V=Vnc servisi, yeşil=Aktif masaüsütü kontrolü açık/Aktif masaüsütü kontrolü kırmızı=kapalı&lt;br/&gt;S=Ssh servisi, yeşil=Uzak terminal açık/kırmızı=Uzak terminal kapalı&lt;br/&gt;R=Xrdp servisi, yeşil=Uzak masaüstü kontrolü açık/kırmızı=uzak masaüstü kontrolü kapalı&lt;br/&gt;X=x11 ekranı, yeşil=Kullanıcı login olmuş/kırmızı=kullanıcı login olmamış</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../baseWidget.h" line="195"/>
        <source>Temel İşlemler Yardım Penceresi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filecopyWidget.h" line="12"/>
        <source>Dosya Kopyalama Penceresi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filecopyWidget.h" line="36"/>
        <source>Dosya
Seç</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filecopyWidget.h" line="44"/>
        <location filename="../videoWidget.h" line="108"/>
        <source>Dosya Seç</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filecopyWidget.h" line="44"/>
        <source>Files (*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filecopyWidget.h" line="49"/>
        <source>Dosya Seçildi.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filecopyWidget.h" line="57"/>
        <source>Pc&apos;lere
Kopyala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filecopyWidget.h" line="98"/>
        <source>Paketi
Kur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filecopyWidget.h" line="151"/>
        <source>Scripti
Çalıştır</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filecopyWidget.h" line="206"/>
        <source>Masaüstüne
Gönder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filecopyWidget.h" line="244"/>
        <source>Çalışma
 Dağıt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filecopyWidget.h" line="287"/>
        <source>Çalışma
 Topla</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filecopyWidget.h" line="322"/>
        <source>&lt;center&gt;&lt;h2&gt;Dosya Kopyalama&lt;/h2&gt;&lt;/center&gt;&lt;center&gt;&lt;img src=&quot;:/icons/dosyakopyalama.png&quot; /&gt;&lt;/center&gt; &lt;center&gt;&lt;img src=&quot;:/icons/istemci.png&quot; /&gt;&lt;/center&gt;&lt;br/&gt;&lt;br/&gt;1-Klasör içeriğinin tamamını kopyalamak için dosya ismi yerine * konulması gerekir;&lt;br/&gt; Örneğin: /home/user/* şeklinde klasör içeriğini kopyalar.&lt;br/&gt;&lt;br/&gt;2-İstemcide açık kullanıcı masaüstüne dosya kopyalama için Masaüstlerine Dağıt seçeneğini kullanabilirsiniz.&lt;br/&gt;&lt;br/&gt;3-İstemcide açık kullanıcı masaüstüne çalışma dosyası göndermek için Çalışmaları Dağıt seçeneğini kullanabilirsiniz.&lt;br/&gt;&lt;br/&gt;4-İstemcide açık kullanıcı masaüstündeki çalışma dosyasını Sunucuya toplamak için Çalışmaları Topla seçeneğini kullanabilirsiniz.&lt;br/&gt;&lt;br/&gt;5-&lt;b&gt;Pc&apos;lere Kopyala&lt;/b&gt; seçeneği Client&apos;de açık kullanıcının ev dizinine kopyalanacaktır.&lt;br/&gt;&lt;br/&gt;6-Birden fazla istemciye kopyalama için istemcileri seçerek kopyalanabilir.&lt;br/&gt;&lt;br/&gt;7-&lt;b&gt;Paketi Kur&lt;/b&gt; seçeneği ile deb uzantılı paketi istemciye kururulumu yapılır.&lt;br/&gt;&lt;br/&gt;8-&lt;b&gt;Scripti Çalıştır&lt;/b&gt; seçeneği ile scripti istemci üzerinde çalıştırır.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../filecopyWidget.h" line="352"/>
        <source>Dosya Kopyalama Yardım Penceresi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languageWidget.h" line="12"/>
        <source>Çoklu Dil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languageWidget.h" line="42"/>
        <source>Dil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="101"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="136"/>
        <source>Temel İşlemler</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="137"/>
        <source>Ekran Paylaşımı</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="139"/>
        <source>Mesaj Yaz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="140"/>
        <source>Dosya Kopyala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="141"/>
        <source>Video/Kamera</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="142"/>
        <source>Ayarlar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="143"/>
        <source>İşlem Raporu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="319"/>
        <source>Açık Hosts : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="429"/>
        <source>Pc Adı: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="430"/>
        <source>Ip: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="431"/>
        <source>Mac: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="433"/>
        <source>Kullanıcı: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="435"/>
        <source>Sistem: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="34"/>
        <source>Güncelle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="47"/>
        <source> Paket Problemleri Düzelt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="60"/>
        <source> Paket Yükleme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="66"/>
        <source>apt-get install paket</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="73"/>
        <source> Paket Kaldırma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="86"/>
        <source> Klasör Oluştur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="92"/>
        <source>mkdir klasor </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="98"/>
        <source> Klasör Sil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="104"/>
        <source>rmdir klasor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="111"/>
        <source> Oturum Aç</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="117"/>
        <source>sshlogin &lt;user&gt; &lt;password&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="125"/>
        <source> Pc&apos;yi Kapat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="138"/>
        <source> Pc&apos;yi Yeniden Başlat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="186"/>
        <source>Tümünü Kapat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="200"/>
        <source>Tümünü Y. Başlat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="236"/>
        <source>Tüm Ekranları İzle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="249"/>
        <source>İzlemeleri Durdur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="287"/>
        <source> Seçili Pc&apos;de Çalıştır</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="302"/>
        <source> Tüm Pc&apos;lerde Çalıştır</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="347"/>
        <source>Oturumları Kapat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="358"/>
        <source>Oturumları Aç</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="394"/>
        <source> Vnc-Seçili Pc&apos;ye Bağlan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="409"/>
        <source> Ekranı Pc&apos;lere Yansıt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="422"/>
        <source> Ekran Yansıtmayı Durdur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="434"/>
        <source> Seçili Pc&apos;lere Yansıt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="446"/>
        <source> Seçili Pc&apos;lerden Ynst Durdur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="459"/>
        <source> Rdp-Seçili Pc&apos;ye Bağlan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="517"/>
        <location filename="../menu.h" line="528"/>
        <location filename="../menu.h" line="538"/>
        <source>Vnc Bağlan-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="556"/>
        <source>Ekranı Yansıt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="561"/>
        <source>Ekranı Yansıtmayı Durdur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="571"/>
        <source>Ftp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="587"/>
        <location filename="../powerrebootWidget.h" line="45"/>
        <source>Yeniden Başlat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="592"/>
        <location filename="../powerrebootWidget.h" line="31"/>
        <source>Kapat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../loginLogoutWidget.h" line="12"/>
        <source>Oturum Seçenekleri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../loginLogoutWidget.h" line="51"/>
        <location filename="../menu.h" line="597"/>
        <source>Oturum Aç</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../loginLogoutWidget.h" line="33"/>
        <location filename="../menu.h" line="602"/>
        <source>Oturum Kapat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="607"/>
        <source>Duyuru İlet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="612"/>
        <location filename="../screenViewWidget.h" line="27"/>
        <source>Ekran İzle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="617"/>
        <source>Ekran İzlemeyi Durdur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="138"/>
        <location filename="../menu.h" line="622"/>
        <source>Komut Çalıştır</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="627"/>
        <location filename="../volumeWidget.h" line="39"/>
        <source>Ses Aç</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="633"/>
        <location filename="../volumeWidget.h" line="27"/>
        <source>Ses Kapat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="639"/>
        <source>Listeden Gizle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../menu.h" line="776"/>
        <source>Uygulama dilinin değişmesi için uygulamayı yeniden başlatın.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selectpc.h" line="29"/>
        <source>&amp;İstemci Seç</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="184"/>
        <location filename="../SettingsWidget.h" line="431"/>
        <location filename="../selectpc.h" line="30"/>
        <location filename="../wolWidget.h" line="21"/>
        <source>Seç</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selectpc.h" line="31"/>
        <source>İstemcileri Seçme Yapıldı</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selectpc.h" line="34"/>
        <source>&amp;Uzak Masaüstü Bağlantısı</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selectpc.h" line="36"/>
        <source>Uzak Masaüstü Bağlantısı Başlatıldı</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selectpc.h" line="40"/>
        <source>&amp;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selectpc.h" line="41"/>
        <source>XRDP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selectpc.h" line="42"/>
        <source>xrdp Uzak Masaüstü Erişimi Yapıldı</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selectpc.h" line="45"/>
        <source>&amp;Terminal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selectpc.h" line="47"/>
        <source>Terminal Bağlantısı Yapıldı</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selectpc.h" line="51"/>
        <source>&amp;Uzak Pc Başlatma</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selectpc.h" line="52"/>
        <source>WOL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selectpc.h" line="53"/>
        <source>Uzaktan Pc Başlatma İşlemi Yapıldı</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selectpc.h" line="56"/>
        <source>&amp;Ağ Profilleri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../selectpc.h" line="57"/>
        <source>AP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../SettingsWidget.h" line="20"/>
        <location filename="../selectpc.h" line="58"/>
        <source>Ağ Profilleri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videoWidget.h" line="22"/>
        <source>Video Dosyası:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videoWidget.h" line="63"/>
        <source>Kamera ve Ses:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videoWidget.h" line="76"/>
        <source>Videoyu
Çalıştır</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videoWidget.h" line="108"/>
        <source>Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videoWidget.h" line="124"/>
        <source>Kamerayı
Çalıştır</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videoWidget.h" line="143"/>
        <source>Videoyu
Durdur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videoWidget.h" line="150"/>
        <source>Video durduruldu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videoWidget.h" line="166"/>
        <source>Kamerayı
Durdur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videoWidget.h" line="188"/>
        <source>Pc&apos;ye
Yayınla</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videoWidget.h" line="210"/>
        <source>Pc Yayını
Durdur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videoWidget.h" line="235"/>
        <source>&lt;center&gt;&lt;h2&gt;Video/Kamera Yayını&lt;/h2&gt;&lt;/center&gt;&lt;center&gt;&lt;img src=&quot;:/icons/video.png&quot; /&gt;&lt;/center&gt; &lt;br/&gt;1-Sunucudaki bir Video Dosyası/Kamera login olmuş kullanıcılarda paylaşılabillir.&lt;center&gt;&lt;img src=&quot;:/icons/istemci.png&quot; /&gt;&lt;/center&gt;&lt;br/&gt;&lt;br/&gt;2-Video Dosyası/Kamera sadece X işareti yeşil olan istemcilere paylaşılabilir.&lt;br/&gt;&lt;br/&gt;3-İstemci simgelerinin altındaki X işareti login olmuş kullanıcıyı ifade eder.&lt;br/&gt;&lt;br/&gt;4-X işareti yeşilse kullanıcı login olduğunu ifade eder. Kırmızı ise login olmadığını ifade eder.&lt;br/&gt;&lt;br/&gt;5-Birden fazla istemciye Video Dosyası/Kamera paylaşmak için istemci seçilerek paylaşılabilir.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../videoWidget.h" line="261"/>
        <source>Video/Kamera Yayın Yardım Penceresi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../lockWidget.h" line="10"/>
        <location filename="../screenViewWidget.h" line="10"/>
        <location filename="../vncrdpWidget.h" line="11"/>
        <source>Ekran Yansıtma Seçenekleri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../lockWidget.h" line="30"/>
        <source>Şeffaf Kilit Aç</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../lockWidget.h" line="46"/>
        <source>Şeffaf Kilitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../lockWidget.h" line="89"/>
        <source>Kilit Seçenekleri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../lockWidget.h" line="107"/>
        <location filename="../menu.h" line="577"/>
        <source>Kilitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../lockWidget.h" line="129"/>
        <location filename="../lockWidget.h" line="193"/>
        <source>Seçili Hostlarda Ekran Kilitlendi.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../lockWidget.h" line="139"/>
        <location filename="../menu.h" line="582"/>
        <source>Kilit Aç</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../lockWidget.h" line="208"/>
        <source>Seçili Hostlar Şeffaf Kilitlendi.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../lockWidget.h" line="222"/>
        <source>Seçili Hostlarda Kilit Açıldı.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../lockWidget.h" line="236"/>
        <source>Seçili Hostlarda Şeffaf Kilit Açıldı.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../lockWidget.h" line="250"/>
        <location filename="../lockWidget.h" line="307"/>
        <source> Tümünü Kilitle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../lockWidget.h" line="265"/>
        <location filename="../lockWidget.h" line="321"/>
        <source> Tüm Kilitleri Aç</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../messageWidget.h" line="12"/>
        <source>Duyuru Mesaj Penceresi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../messageWidget.h" line="18"/>
        <source>Mesaj / Duyuru</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../messageWidget.h" line="29"/>
        <source>Seçili Pc&apos;lere Gönder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../messageWidget.h" line="35"/>
        <location filename="../runcommandWidget.h" line="52"/>
        <location filename="../runcommandWidget.h" line="71"/>
        <location filename="../volumeWidget.h" line="42"/>
        <source>Pc Seçiniz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../messageWidget.h" line="47"/>
        <source>Tüm Pc&apos;lere Gönder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../messageWidget.h" line="54"/>
        <source>Ağ&apos;a Mesaj Gönderildi.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../messageWidget.h" line="70"/>
        <source>&lt;center&gt;&lt;h2&gt;Mesaj Gönderme&lt;/h2&gt;&lt;/center&gt;&lt;center&gt;&lt;img src=&quot;:/icons/mesaj.png&quot; /&gt;&lt;/center&gt; &lt;br/&gt;1-Mesaj sadece X işareti yeşil olan istemcilere gönderilebilir.&lt;center&gt;&lt;img src=&quot;:/icons/istemci.png&quot; /&gt;&lt;/center&gt;&lt;br/&gt;&lt;br/&gt;2-İstemci simgelerinin altındaki X işareti login olmuş kullanıcıyı ifade eder.&lt;br/&gt;&lt;br/&gt;3-X işareti yeşilse kullanıcı login olduğunu ifade eder. Kırmızı ise login olmadığını ifade eder.&lt;br/&gt;&lt;br/&gt;4-Birden fazla istemciye mesaj göndermek için istemciler seçilerek gönderilebilir.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../messageWidget.h" line="95"/>
        <source>Mesaj Gönderme Penceresi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../powerrebootWidget.h" line="11"/>
        <source>Kapatma ve Yeniden Başlatma Seçenekleri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../powerrebootWidget.h" line="97"/>
        <source>Seçili Hostlar Yeniden Başlatıldı.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../powerrebootWidget.h" line="115"/>
        <source>Tüm Hostlar Yeniden Başlatıldı.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../powerrebootWidget.h" line="133"/>
        <source>Seçili Hostlar Kapatıldı.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../powerrebootWidget.h" line="151"/>
        <source>Tüm Hostlar Kapatıldı.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../runcommandWidget.h" line="18"/>
        <source>Komut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../runcommandWidget.h" line="27"/>
        <source>Hazır
Komutlar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../runcommandWidget.h" line="50"/>
        <source>Terminalde
Çalıştır</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../runcommandWidget.h" line="64"/>
        <source>Masaüstlerinde
 Çalıştır</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../runcommandWidget.h" line="92"/>
        <source>&lt;center&gt;&lt;h2&gt;Komut Çalıştırma&lt;/h2&gt;&lt;/center&gt;&lt;center&gt;&lt;img src=&quot;:/icons/runcommand.png&quot; /&gt;&lt;/center&gt; &lt;center&gt;&lt;img src=&quot;:/icons/istemci.png&quot; /&gt;&lt;/center&gt;&lt;br/&gt;&lt;br/&gt;1-Terminalde çalıştır işlemi arka planda terminalde root kullanıcısı olarak işlemleri yapar.&lt;br/&gt;&lt;br/&gt;2-Masaüstünde çalıştırma işlemi Client üzerinde açık kullanılan aktif masaüstünde çalışacak ve kullanıcı görecektir.&lt;br/&gt;Örneğin kullanıcının ekranında hesap makinesi çalıştırmak için; &lt;b&gt;xcalc&lt;/b&gt; komutunu yazıp çalıştırabilirsiniz.&lt;br/&gt;&lt;br/&gt;3-Komutlar Client root hesabı üzerinden çalıştırılmaktadır.&lt;br/&gt;Örneğin, &quot;rm cp mv mkdir rmdir vb.&quot; komutlar Client root kullanıcısının ev dizinde işlemler yapar.&lt;br/&gt;&lt;br/&gt;4-Birden fazla istemcide komut çalıştırmak için istemcileri seçip çalıştırablirsiniz.&lt;br/&gt;&lt;br/&gt;5-İstemcilerde script dosyası çalıştırmak için;&lt;br/&gt;Örneğin: install.sh dosyasını bash install.sh şeklinde yazıp istemcilerde çalıştırabiliriz.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../runcommandWidget.h" line="121"/>
        <source>Komut Çalıştırma Yardım Penceresi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../runcommandWidget.h" line="196"/>
        <source>Komut Tüm Hostlarda Çalıştırıldı.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screenViewWidget.h" line="42"/>
        <source>İzleme Durdur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screenViewWidget.h" line="86"/>
        <source>Seçili Ekran İzlemeler Başlatıldı.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screenViewWidget.h" line="98"/>
        <source>Seçili Ekran İzlemeler Durduruldu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screenViewWidget.h" line="109"/>
        <source>Tüm Ekran İzlemeler Başlatıldı.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../screenViewWidget.h" line="121"/>
        <source>Tüm Ekran İzlemeler Durduruldu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sliderWidget.h" line="68"/>
        <source>Host Boyutları Değiştirildi.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../vncrdpWidget.h" line="29"/>
        <source>Sunucuyu
Kontrol 
Edebilsin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../vncrdpWidget.h" line="42"/>
        <source>Vnc Ekran
 Erişimi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../vncrdpWidget.h" line="55"/>
        <source>Rdp Ekran
 Erişimi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../vncrdpWidget.h" line="60"/>
        <source>Sunucu Ekran Boyutu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../vncrdpWidget.h" line="82"/>
        <source>Ekranı Pc&apos;lere
 Yansıt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../vncrdpWidget.h" line="109"/>
        <source>Yansıtmayı 
Durdur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../vncrdpWidget.h" line="128"/>
        <source>&lt;center&gt;&lt;h2&gt;Ekran Paylaşımı&lt;/h2&gt;&lt;/center&gt;&lt;center&gt;&lt;img src=&quot;:/icons/ekranpaylasimi.png&quot; /&gt;&lt;/center&gt; &lt;br/&gt;1-Ekran paylaşımı vnc servisi ile çalıştırılmaktadır.&lt;center&gt;&lt;img src=&quot;:/icons/istemci.png&quot; /&gt;&lt;/center&gt;&lt;br/&gt;2-İstemci simgelerinin altındaki V işareti vnc servisini ifade eder.&lt;br/&gt;&lt;br/&gt;3-V işareti yeşilse vnc çalışıyor. Kırmızı ise vnc çalışmıyordur.&lt;br/&gt;&lt;br/&gt;4-Sorunsuz ekran paylaşımı yapmak için istemcilerde vnc servisinin çalışıyor olması gerekmektedir.&lt;br/&gt;&lt;br/&gt;5-Sunucu ekranı paylaşılırken, istemci ekranında hangi çözünürlükte görülmesini istiyorsak çözünürlük seçenekleri kullanılınabilir.&lt;br/&gt;&lt;br/&gt;6-Sunucu ekranı paylaşılırken, istemciler ekranı kontrol edip/edemeyeceği seçilebilir.&lt;br/&gt;&lt;br/&gt;7-Canlı istemci ekranına erişim &quot;Vnc Ekran Erişimi&quot; ile yapılabilir.&lt;br/&gt;&lt;br/&gt;8-Canlı istemci ekranından bağımsız erişim &quot;Rdp Ekran Erişimi&quot; ile yapılabilir.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../vncrdpWidget.h" line="157"/>
        <source>Ekran Paylaşımı Yardım Penceresi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../vncrdpWidget.h" line="218"/>
        <source>Seçili Hostda Vnc Başlatıldı.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../vncrdpWidget.h" line="252"/>
        <source>Seçili Hostlarda Ekran Yansıtma Durduruldu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../vncrdpWidget.h" line="275"/>
        <source>Tüm Hostlara Ekran Yansıltıldı.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../vncrdpWidget.h" line="291"/>
        <source>Tüm Hostlarda Ekran Yansıtma Durduruldu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../vncrdpWidget.h" line="297"/>
        <source>XRDP Erişim Bilgileri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../vncrdpWidget.h" line="297"/>
        <source>Client Kullanıcı Adını Girizin
Açık Masaüsütünü Kontrol Etmek için VNC Tercih Edin.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../vncrdpWidget.h" line="306"/>
        <source>İstemcideki Kullanıcının Parolasını Giriniz :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../vncrdpWidget.h" line="315"/>
        <source> Client Bilgisayar Seçiniz...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../vncrdpWidget.h" line="326"/>
        <source>Seçili Hostda Rdp Başlatıldı.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../volumeWidget.h" line="9"/>
        <source>Ses Seçenekleri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../wolWidget.h" line="8"/>
        <source>Kapalı Host Listesi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../wolWidget.h" line="61"/>
        <source>Seçili Pc&apos;leri Aç</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../wolWidget.h" line="88"/>
        <source>Tüm Pc&apos;leri Aç</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../wolWidget.h" line="149"/>
        <source>Seçili Hostlar Uzaktan  Başlatıl.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MyDialog</name>
    <message>
        <location filename="../MyDialog.h" line="16"/>
        <source>Tamam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MyDialog.h" line="20"/>
        <source>Vazgeç</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../MyDialog.h" line="23"/>
        <source>Evet</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
